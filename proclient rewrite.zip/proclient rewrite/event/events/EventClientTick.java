package proclient.event.events;

import proclient.event.Event;

public class EventClientTick extends Event {
    
}
