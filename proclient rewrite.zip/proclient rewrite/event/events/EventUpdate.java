package proclient.event.events;

import proclient.event.Event;

public class EventUpdate extends Event<EventUpdate> {
}
