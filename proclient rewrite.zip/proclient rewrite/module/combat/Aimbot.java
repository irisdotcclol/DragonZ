package proclient.module.combat;

import java.util.List;

import proclient.module.Category;
import proclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;

public class Aimbot extends Module {

    // SETTINGS
    // Adjust this value! 
    // 1.0F = Slow/Smooth
    // 5.0F = Fast
    // 180.0F = Instant Snap
    public static float aimSpeed = 90.0F; 
    public static float range = 4.5F;

    public Aimbot() {
        super("Aimbot", KeyboardConstants.KEY_NONE, Category.COMBAT);
    }

    @Override
    public void onUpdate() {
        if (this.isToggled()) {
            this.aim();
        }
    }

    private void aim() {
        EntityPlayer target = getClosestPlayer();
        
        // Only aim if a target exists and is visible
        if (target != null && Minecraft.getMinecraft().thePlayer.canEntityBeSeen(target)) {
            faceEntity(target);
        }
    }

    // Better logic to find the closest player safely
    private EntityPlayer getClosestPlayer() {
        List<EntityPlayer> list = Minecraft.getMinecraft().theWorld.playerEntities;
        EntityPlayer closest = null;
        double lowestDist = range; // Start with max range

        for (EntityPlayer entity : list) {
            // Skip ourselves
            if (entity == Minecraft.getMinecraft().thePlayer) {
                continue;
            }
            
            // Skip dead or invisible players (optional, good for anti-bot)
            if(entity.isDead || entity.isInvisible()) {
                continue;
            }

            double dist = Minecraft.getMinecraft().thePlayer.getDistanceToEntity(entity);
            
            if (dist < lowestDist) {
                lowestDist = dist;
                closest = entity;
            }
        }
        return closest;
    }

    public synchronized void faceEntity(EntityLivingBase entity) {
        final float[] rotations = getRotationsNeeded(entity);

        if (rotations != null) {
            // Get current rotations
            float currentYaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
            float currentPitch = Minecraft.getMinecraft().thePlayer.rotationPitch;

            // Smooth Yaw
            Minecraft.getMinecraft().thePlayer.rotationYaw = smoothRotation(currentYaw, rotations[0], aimSpeed);
            
            // Smooth Pitch (Usually want pitch slightly slower or same speed)
            Minecraft.getMinecraft().thePlayer.rotationPitch = smoothRotation(currentPitch, rotations[1] + 1.0F, aimSpeed);
        }
    }

    // This function handles the smoothing logic
    private float smoothRotation(float current, float target, float maxChange) {
        float change = MathHelper.wrapAngleTo180_float(target - current);
        
        if (change > maxChange) {
            change = maxChange;
        } else if (change < -maxChange) {
            change = -maxChange;
        }
        
        return current + change;
    }

    public static float[] getRotationsNeeded(Entity entity) {
        if (entity == null) {
            return null;
        }

        final double diffX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        final double diffZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY;

        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
            // Aim slightly lower than top of head (eyes)
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
        final float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
        
        return new float[] { yaw, pitch };
    }
}