package proclient.module.combat;

import java.util.Random;

import proclient.module.Category;
import proclient.module.Module;
import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;

public class AutoClicker extends Module {

    // SETTINGS
    // Change these values to customize your speed!
    public static double minCPS = 8.0;
    public static double maxCPS = 12.0;

    // Internal variables for timing
    private long lastClickTime = 0;
    private long nextDelay = 0;
    private Random random = new Random();

    public AutoClicker() {
        super("AutoClicker", KeyboardConstants.KEY_NONE, Category.COMBAT);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        // Reset timing when enabled so it doesn't double-click instantly
        lastClickTime = System.currentTimeMillis();
        updateDelay();
    }

    @Override
    public void onUpdate() {
        if (this.isToggled()) {
            // Check if the left mouse button is held down (optional safety check)
            // Remove the if statement below if you want it to click even when you aren't holding click
            if (mc.gameSettings.keyBindAttack.isKeyDown()) {
                
                // Check if enough time has passed for the next click
                if (System.currentTimeMillis() - lastClickTime >= nextDelay) {
                    try {
                        // Keep the sprint behavior from your original code
                        mc.thePlayer.setSprinting(true);
                        
                        // Perform the click
                        mc.clickMouse();
                        
                        // Reset timer and calculate new random delay
                        lastClickTime = System.currentTimeMillis();
                        updateDelay();
                        
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * Calculates the delay (in milliseconds) before the next click 
     * based on a random value between minCPS and maxCPS.
     */
    private void updateDelay() {
        // Prevent crashing if someone sets values to 0
        double min = Math.max(1, minCPS);
        double max = Math.max(min, maxCPS); // Ensure max is never lower than min

        // Calculate random CPS
        double randomCPS = min + (random.nextDouble() * (max - min));
        
        // Convert CPS to Milliseconds (1000ms / CPS)
        nextDelay = (long) (1000.0 / randomCPS);
    }
}