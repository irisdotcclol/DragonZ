package proclient.module.combat;

import java.util.List;
import java.util.Random;

import proclient.module.Category;
import proclient.module.Module;
import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MathHelper;

public class KillAura extends Module {

    // SETTINGS
    public static double attackRange = 3.1;    // Distance to swing sword
    public static double rotationRange = 6.0;  // Distance to start looking at them
    public static double minCPS = 9.0;         // Minimum Clicks Per Second
    public static double maxCPS = 13.0;        // Maximum Clicks Per Second
    public static boolean autoBlock = true;    // Block with sword automatically

    // Internal variables
    private EntityLivingBase target;
    private long lastAttackTime = 0;
    private long nextAttackDelay = 0;
    private Random random = new Random();

    public KillAura() {
        super("KillAura", KeyboardConstants.KEY_NONE, Category.COMBAT);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
        // Stop blocking if we turn the module off
        if(mc.thePlayer != null && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.gameSettings.keyBindUseItem.pressed = false;
        }
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled())
            return;

        // 1. Find the best target
        updateTarget();

        // 2. If we have a target...
        if (target != null) {
            
            // Rotate to face them (using the smooth logic from your Aimbot)
            faceEntity(target);

            // Check if they are close enough to actually hit
            if (mc.thePlayer.getDistanceToEntity(target) <= attackRange) {
                attackTarget(target);
            } else {
                // If they are in rotation range but NOT attack range, unblock
                stopBlocking();
            }
        } else {
            // No target? Stop blocking.
            stopBlocking();
        }

        super.onUpdate();
    }

    private void updateTarget() {
        List<Entity> entities = mc.theWorld.loadedEntityList;
        double closestDist = rotationRange; // Start with max range
        target = null;

        for (Entity e : entities) {
            // Filter invalid targets
            if (!(e instanceof EntityLivingBase)) continue;
            if (e == mc.thePlayer) continue;
            if (!e.isEntityAlive()) continue;
            
            // Currently set to only target Players. 
            // Remove this line if you want to hit Mobs too:
            if (!(e instanceof EntityPlayer)) continue; 

            double dist = mc.thePlayer.getDistanceToEntity(e);

            if (dist <= closestDist) {
                closestDist = dist;
                target = (EntityLivingBase) e;
            }
        }
    }

    private void attackTarget(EntityLivingBase entity) {
        // Check timing (CPS)
        if (System.currentTimeMillis() - lastAttackTime >= nextAttackDelay) {
            
            // 1. Attack
            mc.thePlayer.swingItem();
            mc.playerController.attackEntity(mc.thePlayer, entity);

            // 2. Reset Timer
            lastAttackTime = System.currentTimeMillis();
            calculateNextDelay();

            // 3. AutoBlock (Visual + Packet) logic
            if (autoBlock && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
                // In 1.8, you often unblock to hit, then block again
                mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
            }
        }
    }

    private void stopBlocking() {
        // Helper to ensure we aren't holding block when we shouldn't be
        if (autoBlock && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.gameSettings.keyBindUseItem.pressed = false; 
        }
    }

    private void calculateNextDelay() {
        double min = Math.max(1, minCPS);
        double max = Math.max(min, maxCPS);
        double randomCPS = min + (random.nextDouble() * (max - min));
        nextAttackDelay = (long) (1000.0 / randomCPS);
    }

    // --- Rotation Logic (Same as Aimbot for consistency) ---

    public synchronized void faceEntity(EntityLivingBase entity) {
        final float[] rotations = getRotationsNeeded(entity);
        if (rotations != null) {
            mc.thePlayer.rotationYaw = rotations[0];
            mc.thePlayer.rotationPitch = rotations[1] + 1.0F; 
        }
    }

    public static float[] getRotationsNeeded(Entity entity) {
        if (entity == null) return null;

        final double diffX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        final double diffZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY;

        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
        final float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
        
        // Simple wrap logic
        return new float[] { 
            Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw), 
            Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch) 
        };
    }
}