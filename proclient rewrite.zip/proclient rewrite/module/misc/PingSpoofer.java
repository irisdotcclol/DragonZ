package proclient.module.misc;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import proclient.Dragon;
import proclient.event.events.EventSendPacket;
import proclient.module.Category;
import proclient.module.Module;
import proclient.settings.Setting;
import proclient.util.TimeHelper;

public class PingSpoofer extends Module {

    // We use CopyOnWriteArrayList to prevent crashes when modifying the list while the game is running
    private final List<PacketWrapper> packetQueue = new CopyOnWriteArrayList<>();
    private TimeHelper timer = new TimeHelper();

    public PingSpoofer() {
        super("Ping Spoofer", KeyboardConstants.KEY_NONE, Category.MISC);
        // Updated settings: Default 500, Min 500, Max 5000
        Dragon.setmgr.rSetting(new Setting("Ping", this, 500, 500, 5000, true));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        // When disabled, immediately send all trapped packets so we don't time out
        releasePackets();
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled()) return;
        
        long delay = (long) Dragon.setmgr.getSettingByName("Ping").getValDouble();

        // Check the queue for packets that have waited long enough
        for (PacketWrapper wrapper : packetQueue) {
            if (timer.getCurrentMS() - wrapper.timestamp >= delay) {
                // Send the packet
                mc.getNetHandler().addToSendQueue(wrapper.packet);
                // Remove from queue
                packetQueue.remove(wrapper);
            }
        }
    }

    // You need to add this Event listener to your module manager/event system
    public void onSendPacket(EventSendPacket event) {
        if (!this.isToggled()) return;

        // We intercept KeepAlive (Latency) and ConfirmTransaction (Lag checks)
        if (event.packet instanceof C00PacketKeepAlive || event.packet instanceof C0FPacketConfirmTransaction) {
            
            // Don't trap packets we are currently releasing (avoids infinite loops)
            // NOTE: Depending on your event system, you might need a specific check here.
            // Usually, addToSendQueue triggers this event again.
            // If your client loops infinitely, we need to bypass the event system in onUpdate.
            // For now, we assume basic list checking:
            
            if(!isPacketInQueue(event.packet)) {
                event.setCancelled(true);
                packetQueue.add(new PacketWrapper(event.packet, timer.getCurrentMS()));
            }
        }
    }
    
    // Helper to prevent double-adding if the event triggers on release
    private boolean isPacketInQueue(Packet p) {
        for(PacketWrapper pw : packetQueue) {
            if(pw.packet == p) return true;
        }
        return false;
    }

    private void releasePackets() {
        try {
            for (PacketWrapper wrapper : packetQueue) {
                mc.getNetHandler().addToSendQueue(wrapper.packet);
            }
            packetQueue.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Simple helper class to store the packet and the time we caught it
    private class PacketWrapper {
        public Packet packet;
        public long timestamp;

        public PacketWrapper(Packet packet, long timestamp) {
            this.packet = packet;
            this.timestamp = timestamp;
        }
    }
}