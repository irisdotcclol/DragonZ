package proclient.module.movement;

import proclient.module.Category;
import proclient.module.Module;
import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.util.MathHelper;

public class Bhop extends Module {

    // Speed setting (0.48 is roughly standard sprint-jump speed)
    // Set higher (e.g. 1.0) for blatant speed, but you might get banned.
    private double speed = 0.48; 

    public Bhop() {
        super("Bhop", KeyboardConstants.KEY_NONE, Category.MOVEMENT);
    }
    
    @Override
    public void onDisable() {
        mc.gameSettings.keyBindJump.pressed = false;
        mc.timer.timerSpeed = 1.0F;
        super.onDisable();
    }
    
    @Override
    public void onUpdate() {
        if(!this.isToggled()) return;

        // Reset jump key state to prevent vanilla interference
        mc.gameSettings.keyBindJump.pressed = false;

        // Only activate if we are actually pressing movement keys
        if(isMoving()) {
            if(mc.thePlayer.onGround) {
                // If on ground, Jump!
                mc.thePlayer.jump();
                // Set the initial jump speed
                setMoveSpeed(speed); 
            } else {
                // If in air, maintain current speed (prevents air friction)
                setMoveSpeed(getCurrentSpeed());
            }
        } else {
            // If not pressing keys, stop sliding
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
        }
    }

    // Helper to check if player is pressing WASD
    public boolean isMoving() {
        return mc.thePlayer.movementInput.moveForward != 0.0F || mc.thePlayer.movementInput.moveStrafe != 0.0F;
    }

    // Helper to get current player speed
    public double getCurrentSpeed() {
        return Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
    }

    // The Magic: Calculates X and Z motion based on Yaw and WASD
    public void setMoveSpeed(double moveSpeed) {
        float forward = mc.thePlayer.movementInput.moveForward;
        float strafe = mc.thePlayer.movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;

        if (forward == 0.0F && strafe == 0.0F) {
            mc.thePlayer.motionX = 0.0D;
            mc.thePlayer.motionZ = 0.0D;
        } else {
            if (forward != 0.0F) {
                if (strafe > 0.0F) {
                    yaw += (float)(forward > 0.0F ? -45 : 45);
                } else if (strafe < 0.0F) {
                    yaw += (float)(forward > 0.0F ? 45 : -45);
                }
                strafe = 0.0F;
                if (forward > 0.0F) {
                    forward = 1.0F;
                } else if (forward < 0.0F) {
                    forward = -1.0F;
                }
            }
            
            double sin = Math.sin(Math.toRadians(yaw));
            double cos = Math.cos(Math.toRadians(yaw));
            
            mc.thePlayer.motionX = forward * moveSpeed * -sin + strafe * moveSpeed * cos;
            mc.thePlayer.motionZ = forward * moveSpeed * cos - strafe * moveSpeed * -sin;
        }
    }
}