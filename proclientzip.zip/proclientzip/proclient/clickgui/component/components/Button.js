export class Button {
    constructor() {
        console.log("Button created");
    }
}

export default Button;
