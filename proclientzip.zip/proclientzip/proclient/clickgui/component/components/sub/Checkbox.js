export class Checkbox {
    constructor() {
        console.log("Checkbox created");
    }
}

export default Checkbox;
