export class Keybind {
    constructor() {
        console.log("Keybind created");
    }
}

export default Keybind;
