export class ModeButton {
    constructor() {
        console.log("ModeButton created");
    }
}

export default ModeButton;
