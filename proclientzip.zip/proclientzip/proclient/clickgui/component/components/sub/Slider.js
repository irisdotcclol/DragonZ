export class Slider {
    constructor() {
        console.log("Slider created");
    }
}

export default Slider;
