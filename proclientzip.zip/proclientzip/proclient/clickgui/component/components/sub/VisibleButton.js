export class VisibleButton {
    constructor() {
        console.log("VisibleButton created");
    }
}

export default VisibleButton;
