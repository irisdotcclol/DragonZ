export const EventDirection = {
    OUTGOING: "OUTGOING",
    INCOMING: "INCOMING"
};
