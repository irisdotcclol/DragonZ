export const EventType = {
    PRE: "PRE",
    POST: "POST"
};
