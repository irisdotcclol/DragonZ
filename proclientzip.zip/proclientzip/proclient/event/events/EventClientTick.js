import { Event } from '../Event.js';

export class EventClientTick extends Event {
}
