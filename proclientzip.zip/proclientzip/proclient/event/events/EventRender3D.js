import { Event } from '../Event.js';

export class EventRender3D extends Event {
}
