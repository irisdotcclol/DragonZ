import { Event } from '../Event.js';

export class EventRenderGUI extends Event {
}
