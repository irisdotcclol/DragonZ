import { Event } from '../Event.js';

export class EventRenderNametag extends Event {
}
