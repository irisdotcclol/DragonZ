import { Event } from '../Event.js';

export class EventRenderWorld extends Event {
}
