import { Event } from '../Event.js';

export class EventSafewalk extends Event {
}
