import { Event } from '../Event.js';

export class EventUpdate extends Event {
}
