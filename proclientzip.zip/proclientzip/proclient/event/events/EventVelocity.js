import { Event } from '../Event.js';

export class EventVelocity extends Event {
}
