export class ArrayList {
    constructor() {
        console.log("ArrayList initialized");
    }
}

export default ArrayList;
