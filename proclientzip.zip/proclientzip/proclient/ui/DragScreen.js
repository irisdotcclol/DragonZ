export class DragScreen {
    constructor() {
        console.log("DragScreen initialized");
    }
}

export default DragScreen;
