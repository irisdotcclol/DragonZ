export class MainMenu {
    constructor() {
        console.log("MainMenu initialized");
    }
}

export default MainMenu;
