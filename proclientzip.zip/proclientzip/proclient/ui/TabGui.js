export class TabGui {
    constructor() {
        console.log("TabGui initialized");
    }
}

export default TabGui;
