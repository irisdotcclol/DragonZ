export class AnimatedResourceLocation {
    constructor(...args) {
        this.args = args;
    }
}

export default AnimatedResourceLocation;
