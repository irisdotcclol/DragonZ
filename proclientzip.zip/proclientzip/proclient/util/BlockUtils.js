export class BlockUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default BlockUtils;
