export class ChestEspUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default ChestEspUtil;
