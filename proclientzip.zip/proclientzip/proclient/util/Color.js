export class Color {
    constructor(...args) {
        this.args = args;
    }
}

export default Color;
