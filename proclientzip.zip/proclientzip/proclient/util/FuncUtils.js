export class FuncUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default FuncUtils;
