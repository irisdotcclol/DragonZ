export class MathUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default MathUtil;
