export class MobEspUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default MobEspUtil;
