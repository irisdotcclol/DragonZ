export class MoveUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default MoveUtils;
