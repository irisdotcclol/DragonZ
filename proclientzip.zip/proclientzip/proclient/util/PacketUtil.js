export class PacketUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default PacketUtil;
