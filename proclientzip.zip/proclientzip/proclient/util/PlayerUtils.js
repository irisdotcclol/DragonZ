export class PlayerUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default PlayerUtils;
