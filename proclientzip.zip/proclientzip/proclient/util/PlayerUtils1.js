export class PlayerUtils1 {
    constructor(...args) {
        this.args = args;
    }
}

export default PlayerUtils1;
