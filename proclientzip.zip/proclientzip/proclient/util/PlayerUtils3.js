export class PlayerUtils3 {
    constructor(...args) {
        this.args = args;
    }
}

export default PlayerUtils3;
