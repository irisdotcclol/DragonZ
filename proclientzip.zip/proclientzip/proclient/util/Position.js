export class Position {
    constructor(...args) {
        this.args = args;
    }
}

export default Position;
