export class RenderShit {
    constructor(...args) {
        this.args = args;
    }
}

export default RenderShit;
