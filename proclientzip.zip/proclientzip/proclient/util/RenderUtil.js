export class RenderUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default RenderUtil;
