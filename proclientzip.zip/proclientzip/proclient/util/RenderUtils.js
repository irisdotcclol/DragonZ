export class RenderUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default RenderUtils;
