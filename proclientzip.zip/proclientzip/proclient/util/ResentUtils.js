export class ResentUtils {
    constructor(...args) {
        this.args = args;
    }
}

export default ResentUtils;
