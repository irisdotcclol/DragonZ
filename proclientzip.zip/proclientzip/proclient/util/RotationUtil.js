export class RotationUtil {
    constructor(...args) {
        this.args = args;
    }
}

export default RotationUtil;
