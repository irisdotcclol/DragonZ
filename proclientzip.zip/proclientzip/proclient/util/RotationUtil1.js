export class RotationUtil1 {
    constructor(...args) {
        this.args = args;
    }
}

export default RotationUtil1;
