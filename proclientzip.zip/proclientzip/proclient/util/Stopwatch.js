export class Stopwatch {
    constructor(...args) {
        this.args = args;
    }
}

export default Stopwatch;
