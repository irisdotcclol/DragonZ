export class TimeHelper {
    constructor(...args) {
        this.args = args;
    }
}

export default TimeHelper;
