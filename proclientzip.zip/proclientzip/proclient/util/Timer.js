export class Timer {
    constructor(...args) {
        this.args = args;
    }
}

export default Timer;
